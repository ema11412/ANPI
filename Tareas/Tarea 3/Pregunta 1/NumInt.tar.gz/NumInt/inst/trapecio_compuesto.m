function I = trapecio_compuesto(f, a, b, n)
  
  %Esta funci�n encuentra una aproximaci�n de la integral de una funci�n en un intervalo dado con la regla del trapecio compuesto
  %
  %Sintaxis: trapecio_compuesto(f, a, b, n)
  %
  %Par�metros Iniciales: 
  %            f = funci�n a integrar
  %            a = inicio del intervalo de integraci�n
  %            b = final del intervalo de integraci�n
  %            n = cantidad de subintervalos a realizar
  %   
  %Par�metros de Salida:                           
  %            I = valor aproximado de la integral en el intervalo espec�ficado
  
  pkg load symbolic
  
  func = matlabFunction(sym(f));
  
  h = (b - a) / (n - 1);
  
  i = 1;
  x(i) = a;
  while i < n
    x(i + 1) = a + (i * h);
    i += 1;
  end
  
  i = 1;
  sum = 0;
  cantVars = length(x);
  
  while i < cantVars
    sum += (func(x(i)) + func(x(i + 1)));
    i += 1;
  end
  
  I = (h / 2) * sum;
  
end