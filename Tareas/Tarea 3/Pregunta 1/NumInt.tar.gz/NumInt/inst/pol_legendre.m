function p = pol_legendre(n)
  
  %Esta funci�n encuentra el polinomio de Legendre de grado n
  %
  %Sintaxis: pol_legendre(n)
  %
  %Par�metros Iniciales: 
  %            n = es el grado del polinomio de legendre a calcular
  %   
  %Par�metros de Salida:                           
  %            p = polinomio de lengendre
  
  pkg load symbolic
  
  syms x
  
  a = 1 / (factorial(n) * (2**n));
  
  b = a * (((x**2) - 1)**n);
  
  for i = 1:n
    b = matlabFunction(diff(sym(b)));
  end
  
  p = b;
  
end
