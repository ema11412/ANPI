function I = simpson(f, a, b)
  
  %Esta funci�n encuentra una aproximaci�n de la integral de una funci�n en un intervalo dado con la regla de simpson
  %
  %Sintaxis: simpson(f, a, b)
  %
  %Par�metros Iniciales: 
  %            f = funci�n a integrar
  %            a = inicio del intervalo de integraci�n
  %            b = final del intervalo de integraci�n
  %   
  %Par�metros de Salida:                           
  %            I = valor aproximado de la integral en el intervalo espec�ficado
  
  pkg load symbolic
  
  func = matlabFunction(sym(f));
  
  h = (b - a) / 2;
  x1 = (a + b) / 2;
  
  I = (h / 3) * (func(a) + 4 * func(x1) + func(b));
  
end