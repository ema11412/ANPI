function I = trapecio(f, a, b)
  
  %Esta funci�n encuentra una aproximaci�n de la integral de una funci�n en un intervalo dado con la regla del trapecio
  %
  %Sintaxis: trapecio(f, a, b)
  %
  %Par�metros Iniciales: 
  %            f = funci�n a integrar
  %            a = inicio del intervalo de integraci�n
  %            b = final del intervalo de integraci�n
  %   
  %Par�metros de Salida:                           
  %            I = valor aproximado de la integral en el intervalo espec�ficado
  
  pkg load symbolic
  
  func = matlabFunction(sym(f));
  
  h = b - a;
  
  I = (h / 2) * (func(a) + func(b));
  
end