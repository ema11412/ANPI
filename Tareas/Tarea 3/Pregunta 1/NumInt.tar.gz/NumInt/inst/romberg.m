function I = romberg(f, a, b, n)
  
  %Esta funci�n encuentra una aproximaci�n de la integral de una funci�n en un intervalo dado con el m�todo de Romberg
  %
  %Sintaxis: romberg(f, a, b, n)
  %
  %Par�metros Iniciales: 
  %            f = funci�n a integrar
  %            a = inicio del intervalo de integraci�n
  %            b = final del intervalo de integraci�n
  %            n = cantidad de filas de la tabla de Romberg a realizar
  %   
  %Par�metros de Salida:                           
  %            I = valor aproximado de la integral en el intervalo espec�ficado
  
  pkg load symbolic
  
  func = matlabFunction(sym(f));
  
  h = b - a;
  R = zeros(n, n);
  
  R(1,1) = (func(a) + func(b)) * (h / 2);
  
  for k = 2:n
    h(k) = (b - a) / (2**(k - 1));
    sum = 0;
    
    for i = 1:(2**(k-2))
      sum += func(a + (((2 * i) - 1) * h(k)));
    end
    
    R(k,1) = 0.5 * (R(k-1,1) + (h(k-1) * sum));
    
    for j = 2:k
      R(k,j) = R(k,j-1) + ((1 / (4**(j-1) - 1)) * (R(k,j-1) - R(k-1,j-1)));
    end
  end
  
  I = R(n,n);
  
end