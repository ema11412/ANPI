function I = gaussiana_compuesta(f, a, b, m, n)
  
  %Esta funci�n encuentra una aproximaci�n de la integral de una funci�n en un intervalo dado con el m�todo de cuadraturas gaussianas compuesto
  %
  %Sintaxis: gaussiana_compuesta(f, a, b, m, n)
  %
  %Par�metros Iniciales: 
  %            f = funci�n a integrar
  %            a = inicio del intervalo de integraci�n
  %            b = final del intervalo de integraci�n
  %            m = grado del polinomio de Legendre a calcular
  %            n = cantidad de subintervalos a realizar
  %   
  %Par�metros de Salida:                           
  %            I = valor aproximado de la integral en el intervalo espec�ficado
  
  pkg load symbolic
  
  syms x
  
  func = matlabFunction(sym(f));
  
  h = (b - a) / (n - 1);
  
  i = 1;
  X(i) = a;
  while i < n
    X(i + 1) = a + (i * h);
    i += 1;
  end
  
  p = pol_legendre(m);
  dp = matlabFunction(diff(sym(p)));
  
  sol = solve(p, x);
  
  cantVars = length(X);
  I = 0;
  Itemp = 0;
  
  for i = 1:m
      w(i) = 2 / ((1 - (sol(i)**2)) * (dp(sol(i))**2));
  end
  
  i = 1;
  
  while i < cantVars
    g = func((((X(i + 1) - X(i)) * x) + (X(i + 1) + X(i))) / 2);
    
    for j = 1:n
      Itemp += double(w(j) * subs(g, x, sol(j)));
    end
  
    Itemp *= (X(i + 1) - X(i)) / 2;
    
    I += Itemp;
    Itemp = 0;
    
    i += 1;
  end

end