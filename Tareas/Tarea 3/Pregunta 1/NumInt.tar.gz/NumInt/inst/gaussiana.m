function I = gaussiana(f, a, b, m)
  
  %Esta funci�n encuentra una aproximaci�n de la integral de una funci�n en un intervalo dado con el m�todo de cuadraturas gaussianas
  %
  %Sintaxis: gaussiana(f, a, b, m)
  %
  %Par�metros Iniciales: 
  %            f = funci�n a integrar
  %            a = inicio del intervalo de integraci�n
  %            b = final del intervalo de integraci�n
  %            m = grado del polinomio de Legendre a calcular
  %   
  %Par�metros de Salida:                           
  %            I = valor aproximado de la integral en el intervalo espec�ficado
  
  pkg load symbolic
  
  syms x
  
  func = matlabFunction(sym(f));
  
  p = pol_legendre(m);
  dp = matlabFunction(diff(sym(p)));
  
  sol = solve(p, x);
  
  g = func((((b - a) * x) + (b + a)) / 2);
  
  I = 0;
  
  for i = 1:m
    w(i) = 2 / ((1 - (sol(i)**2)) * (dp(sol(i))**2));
    I += double(w(i) * subs(g, x, sol(i)));
  end
  
  I *= (b - a) / 2;
  
end